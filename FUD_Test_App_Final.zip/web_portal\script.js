document.getElementById('loginBtn').addEventListener('click',()=>{
  const email=document.getElementById('email').value;
  const pass=document.getElementById('password').value;
  const msg=document.getElementById('msg');
  if(email==='jarry@fud.local' && pass==='Khadeejace1@'){
    msg.innerText='? Login successful! Redirecting...';
    setTimeout(()=>{window.location.href='dashboard.html';},1500);
  }else msg.innerText='? Invalid email or password';
});
